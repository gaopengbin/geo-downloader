---
name: geod-agent
description: Install and use GeoD MCP for imagery planning, downloads, and inspection. Use browser WebMCP only when the user explicitly requests that route and the browser exposes its tools.
---

# GeoD imagery download

Connect this Agent to GeoD MCP. GeoD is separate from GeoStyle. Do not assume the Agent can access the user's computer or browser: check where this Agent actually runs before choosing a transport.

## Connect

1. For Codex or WorkBuddy running on the user's Windows x64 computer with Node.js 22+, install the local MCP and bundled Skill. In PowerShell, set `$pkg = "https://laogao.xyz/geod-mcp/geod-mcp-0.1.4.tgz"`, then run `npx --yes --package $pkg geod-mcp install codex --package $pkg` (use `workbuddy` instead of `codex` in WorkBuddy). Afterward, update the installed, unmodified bundled `geod-agent/SKILL.md` with this current file. Preserve any user edits and report a conflict instead of overwriting them. The installer configures the current user's MCP and Skill; do not use another person's paths.
2. For a cloud Agent or an environment where the local installer cannot run, add `https://laogao.xyz/geod-mcp/mcp` as a Streamable HTTP MCP server. Let the user authorize it with their own GeoD account in a browser. Read-only planning can use this connection; downloads and mosaics use GeoD server resources, only its listed sources are available, and account limits apply. For large downloads, explain the limitation and use a local-capable Agent instead of silently spending server resources.

Install this `SKILL.md` in the current Agent's supported Skills location; for Codex use `~/.codex/skills/geod-agent/SKILL.md`, and for WorkBuddy import `https://geod.laogao.xyz/skills/geod-agent.zip` if its Skills UI is available. If this client cannot install Skills, read this file as the task guide and report that limitation. A new Agent session may be needed to load an installed Skill or MCP server. Verify setup with MCP tool calls, not by opening a webpage.

## Browser WebMCP (only when requested)

Use `https://geod.laogao.xyz/browser` only if the user explicitly chooses browser processing and this Agent actually receives `geod_browser_*` WebMCP tools from that open page. Merely opening the page, reading its UI, or clicking its controls does not install or verify MCP. If the tools are absent, report that and continue with the MCP setup above. When available, call `geod_browser_capabilities`, `geod_browser_sources` with `action: list`, and `geod_browser_plan`. Use a listed `sourceId`; register an authorized custom source only when the user provides one. The source must permit CORS. `exampleId: "henan"` or `"sichuan"` supplies an example province boundary and range. For another boundary, pass a WGS84 GeoJSON Polygon or MultiPolygon in `clipGeometry`; pixels outside it become transparent. Call `geod_browser_fetch` only when the user asks to download, then have them save the ZIP in the page. Browser output is PNG with positioning files and a manifest; use local MCP for other formats.

## Local or hosted MCP

Call `geod_capabilities` and `geod_sources` with `action: list`; use `imagery.sourceId` from the actual source list. On local MCP, an authorized XYZ/TMS/QuadKey source can be registered with `geod_sources` when needed. Hosted MCP cannot register custom sources. Read `geod://examples/henan` or `geod://examples/sichuan` for request examples, or use the user's WGS84 bounds `[west, south, east, north]`. Do not invent a precise boundary. Call `geod_plan` to validate and estimate size without downloading. When the user asks for the data, call `geod_fetch`, poll `geod_job_status`, inspect the completed manifest, and return the actual source, coverage, warnings, and artifact. Use `geod_get_artifact` for a small preview, `geod_artifact_link` for a large hosted file, or the local path for a local file. Use `geod_inspect` for an existing bundle.

Verify the MCP connection with `geod_capabilities`, source listing, and a read-only `geod_plan`. Do not claim success from webpage interaction alone. Do not start a download or probe a network tile solely to test setup. NASA Blue Marble examples are overview imagery, not current high-resolution imagery. Do not expose source URLs containing credentials.
